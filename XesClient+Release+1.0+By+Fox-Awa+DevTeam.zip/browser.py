import sys,urllib.request,os,json,base64,time,requests
import http.cookiejar

from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWebEngineWidgets import *

app = QApplication(sys.argv)

class window(QWidget):
    def __init__(self):
        super().__init__()
        self.brow = QWebEngineView(self)
        self.initUI()

    def initUI(self):
        self.brow.resize(1000,500)
        self.brow.load(QUrl('http://login.xueersi.com'))
        self.brow.move(0,0)
        self.brow.show()
        self.resize(1000,500)
        self.show()

if __name__ == "__main__":
    w = window()
    sys.exit(app.exec_())