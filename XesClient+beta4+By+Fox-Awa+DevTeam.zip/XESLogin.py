#Author:Fox-Awa组织 desc:本Python是对学而思登录的一个封装。
import requests,json,urllib;
class XESLogin:
    def getcode(self,u,p):
        t=json.loads(requests.post("https://passport.100tal.com/v1/web/captcha/get","symbol="+urllib.parse.quote(u)+"&password="+urllib.parse.quote(p)+"&scene=3",headers={"Content-Type":"application/x-www-form-urlencoded","client-id":"111101","device-id":"null","ver-num":"1.11.03"}).text);
        if "captcha" not in t["data"]:return "";
        return t["data"]["captcha"];
    def verify(self,u,p,s):
        y=json.loads(requests.post("https://passport.100tal.com/v1/web/login/pwd", "symbol="+urllib.parse.quote(u)+"&password="+urllib.parse.quote(p)+"&captcha="+urllib.parse.quote(s),headers={"Content-Type":"application/x-www-form-urlencoded","client-id":"111101","device-id":"null","ver-num":"1.11.03"}).text);
        if "code" not in y["data"]:return {};
        c=requests.post("https://login.xueersi.com/V1/Web/getToken","code="+y["data"]["code"],headers={"Content-Type":"application/x-www-form-urlencoded","client-id":"111101","device-id":"null","ver-num":"1.11.03"}).headers["set-cookie"].replace(" ","").split(";");f=[];n={};
        for a in range(0,len(c)):
            if c[a].split("=")[0]!="path" and c[a].split("=")[0]!="expires" and c[a].split("=")[0]!="domain" and c[a].split("=")[0]!="Max-Age":f.append(c[a]);
        for a in range(0,len(f)):f[a]=f[a].replace("HttpOnly,","");
        for a in range(0,len(f)):n[f[a].split("=")[0]]=f[a].split("=")[1];
        return n;
